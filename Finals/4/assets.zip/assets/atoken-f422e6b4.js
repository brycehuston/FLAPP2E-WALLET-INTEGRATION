const t=`<svg width="100%" height="100%" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0)">
<path d="M12.8862 509.82H83.3388C86.3489 509.82 89.1018 508.123 90.454 505.434L298.671 91.3397C299.832 89.0308 299.8 86.3022 298.586 84.0208L260.211 11.9014C257.779 7.33195 251.202 7.41537 248.887 12.045L5.76289 498.294C3.11521 503.589 6.96582 509.82 12.8862 509.82Z" fill="url(#paint0_linear)"/>
<path d="M321.91 510.615H254.41H188.853C182.869 510.615 179.023 504.263 181.795 498.961L250.319 367.9C253.34 362.123 261.642 362.224 264.522 368.072L329.054 499.133C331.66 504.425 327.809 510.615 321.91 510.615Z" fill="url(#paint1_linear)"/>
<path d="M499.1 510.615H427.077C424.064 510.615 421.309 508.915 419.958 506.222L301.499 270.074C300.383 267.848 300.372 265.227 301.47 262.992L337.172 190.313C340.075 184.402 348.49 184.369 351.44 190.256L506.22 499.082C508.874 504.378 505.024 510.615 499.1 510.615Z" fill="url(#paint2_linear)"/>
</g>
<defs>
<linearGradient id="paint0_linear" x1="17.4907" y1="509.82" x2="257.59" y2="7.36026" gradientUnits="userSpaceOnUse">
<stop stop-color="#1FA2F2"/>
<stop offset="1" stop-color="#3ECCF9"/>
</linearGradient>
<linearGradient id="paint1_linear" x1="255.205" y1="363.534" x2="255.205" y2="510.615" gradientUnits="userSpaceOnUse">
<stop stop-color="#27AEF4"/>
<stop offset="1" stop-color="#1EA2F2"/>
</linearGradient>
<linearGradient id="paint2_linear" x1="345.044" y1="184.652" x2="461.913" y2="501.075" gradientUnits="userSpaceOnUse">
<stop stop-color="#33BDF7"/>
<stop offset="1" stop-color="#1EA1F2"/>
</linearGradient>
<clipPath id="clip0">
<rect width="512" height="512" fill="white"/>
</clipPath>
</defs>
</svg>`;export{t as default};
